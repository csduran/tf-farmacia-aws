import os, json, boto3, logging
logger = logging.getLogger(); logger.setLevel("INFO")
ddb = boto3.resource("dynamodb").Table(os.environ["TABLE_CONNECTIONS"])

def lambda_handler(event, context):
    logger.info({"event": event})
    cid = event.get("requestContext", {}).get("connectionId")
    if cid:
        ddb.put_item(Item={"connectionId": cid})
    return {"statusCode": 200, "body": json.dumps({"ok": True})}
