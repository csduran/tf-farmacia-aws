import json, logging
logger = logging.getLogger(); logger.setLevel("INFO")

def lambda_handler(event, context):
    logger.info({"event": event})
    return {"statusCode": 200, "body": json.dumps({"ok": True, "fn": "processOrder"})}
